---
title: DomObj Object
lang: en-US
---

# `DomObj` Object

#### Source Code

<<< @/build/js/domobj.js
