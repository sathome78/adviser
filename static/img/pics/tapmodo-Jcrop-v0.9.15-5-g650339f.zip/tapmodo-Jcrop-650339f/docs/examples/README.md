# Basic Example

<example1 />

**Basic attachment example.** Implements a single widget and
reactive coordinates display. This is the most common use case,
usually used to select the crop area of an image.

