---
title: Jcrop Roadmap
lang: en-US
footer: MIT Licensed | Copyright © 2008-2018 Tapmodo Interactive LLC
---

# Jcrop Roadmap
